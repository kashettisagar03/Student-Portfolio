import React from "react";
import "./Admin.css";
import { Link } from "react-router-dom";
import AboutAdmin from "./AboutAdmin";
import EducationAdmin from "./EducationAdmin";
import ProjectsAdmin from "./ProjectsAdmin";
import ExperienceAdmin from "./ExperienceAdmin";

const Admin = () => {
  return (
    <div className="main-container">
      <h2 className="title">Admin forms</h2>
      <div className="admin-center">
        {/* about component */}
        <h4 className="admin-title">About component</h4>
        <AboutAdmin />
        <br />
        <br />
        <hr style={{ border: "2px solid lightgrey" }} />
        <br />

        {/* education component */}
        <h4 className="admin-title">Educationn component</h4>
        <EducationAdmin />
        <br />
        <br />
        <hr style={{ border: "2px solid lightgrey" }} />
        <br />

        {/* projects component */}
        <h4 className="admin-title">Projects component</h4>
        <ProjectsAdmin />
        <br />
        <br />
        <hr style={{ border: "2px solid lightgrey" }} />
        <br />

        {/* projects component */}
        <h4 className="admin-title">Experience component</h4>
        <ExperienceAdmin />
        <br />
        <br />
        <hr style={{ border: "2px solid lightgrey" }} />
        <br />
      </div>
    </div>
  );
};

export default Admin;
