import React from 'react';
import { Link } from 'react-router-dom';
const ProjectsAdmin = () => {
  return (
    <div className='same-component'>
      <div className="same-form">
        <form>
          <h4>
            Projects components
          </h4>
         
          <label htmlFor="text">Id</label>
          <input type="text" name='product_id' id='product_id' required/>

          <label htmlFor="text">title</label>
          <input type="text" name='title' id='title' required/>

          <label htmlFor="text">Description</label>
          <textarea type="text" name='description' id='description' required cols='30' rows="3"
          />
           <div className="upload">
            <input type="file"  name='file' id='file_up'/>
            <div id="file_img" >
              <img src="https://it.sheridancollege.ca/images/virtualization.jpg"  width="100%"alt="" />
              <span>X</span>
            </div>
           </div>
           <button>Add Item</button>
        </form>
      </div>
      <div className="same-item">
        <div className="about-info">
          <div className="projects-admin">
            <div className="icons">
            <Link to={"/ediProject"}>
              <i className="fas fa-edit"></i>
            </Link>
            <i className="fas fa-trash"></i>
            </div>

       {/* single projec */}
       <div className="single-project">
        <div className="single-project-img">
          <img src="https://p1.hiclipart.com/preview/39/300/59/project-management-icon-project-icon-business-management-icon-technology-computer-icons-customer-service-education-png-clipart.jpg" alt="" />
        </div>
        <div className="single-project-info">
          <h3>title</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit numquam quaerat minus ducimus! Animi iusto tenetur rem quibusdam, deleniti ex natus voluptatibus temporibus possimus. Dolor ipsam commodi quos vero! Unde!</p>
             
        </div>

       </div>
       <h3 className='item-delete-tab'>item deleted</h3>

          </div>
        </div>
      </div>
    </div>
  );
}

export default ProjectsAdmin;
