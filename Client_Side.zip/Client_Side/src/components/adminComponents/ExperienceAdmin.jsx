import React from 'react';
import { Link } from 'react-router-dom';
import './Admin.css';

const ExperienceAdmin = () => {
  return (
    <div className='same-component'>
      <div className="same-form">
        <form>
          <h4>Experience component</h4>
          <label htmlFor="text">Experience</label>
          <input type="text"  />
          <button type='submit'>Add item</button>
        </form>
      </div>
      <div className="same-item">
        <div className="about-info">
          <div className="same-admin">
         <div className="icons">
         <Link to={"/editExperience"}>
              <i className="fas fa-edit"></i>
            </Link>
            <i className="fas fa-trash"></i>
         </div>
         {/* single experience */}

         <div className="single-experience">
          <p>Designer</p>

         </div>
          <h3 className="item-delete-tab">item deleted</h3>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ExperienceAdmin;
