import React from "react";
import p1 from "../../images/project1.jpg";
import p2 from "../../images/project2.jpg";
import p3 from "../../images/project3.jpg";

const Projects = () => {
  return (
    <div className="main-container">
      <div className="projects">
        <h2 className="title">Projects</h2>
        <div className="projects-center">
          {/* single project */}
          <div className="single-project">
            <div className="single-project-img">
              <img src={p1} alt="" />
            </div>
            <div className="single-project-info">
              <h3>Project 1</h3>
              <p>
                Facilisi etiam dignissim diam quis enim lobortis. Ac placerat
                vestibulum lectus mauris ultrices eros in cursus. Cursus metus
                aliquam eleifend mi. Id interdum velit laoreet id donec ultrices
                tincidunt arcu. Semper eget duis at tellus at.
              </p>
            </div>
          </div>

          {/* single project */}
          <div className="single-project">
            <div className="single-project-img">
              <img src={p2} alt="" />
            </div>
            <div className="single-project-info">
              <h3>Project 2</h3>
              <p>
                Facilisi etiam dignissim diam quis enim lobortis. Ac placerat
                vestibulum lectus mauris ultrices eros in cursus. Cursus metus
                aliquam eleifend mi. Id interdum velit laoreet id donec ultrices
                tincidunt arcu. Semper eget duis at tellus at.
              </p>
            </div>
          </div>

          {/* single project */}
          <div className="single-project">
            <div className="single-project-img">
              <img src={p3} alt="" />
            </div>
            <div className="single-project-info">
              <h3>Project 3</h3>
              <p>
                Facilisi etiam dignissim diam quis enim lobortis. Ac placerat
                vestibulum lectus mauris ultrices eros in cursus. Cursus metus
                aliquam eleifend mi. Id interdum velit laoreet id donec ultrices
                tincidunt arcu. Semper eget duis at tellus at.
              </p>
            </div>
          </div>

          {/* single project */}
          <div className="single-project">
            <div className="single-project-img">
              <img src={p1} alt="" />
            </div>
            <div className="single-project-info">
              <h3>Project 4</h3>
              <p>
                Facilisi etiam dignissim diam quis enim lobortis. Ac placerat
                vestibulum lectus mauris ultrices eros in cursus. Cursus metus
                aliquam eleifend mi. Id interdum velit laoreet id donec ultrices
                tincidunt arcu. Semper eget duis at tellus at.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Projects;
