import React from 'react';

const experience = () => {
  return (
    <div>
      <div className="main-container">
        <h2 className="title">
          Experience
        </h2>
        <div className="experience">
          <div className="experience-center">

             {/* static single experience */}
             <div className="single-experience">
              <p>Self employed software Engineer and Web developer</p>
             </div>

             <div className="single-experience">
              <p>Self employed software Engineer and Web developer</p>
             </div>

             <div className="single-experience">
              <p>Self employed software Engineer and Web developer</p>
             </div>

             <div className="single-experience">
              <p>Self employed software Engineer and Web developer</p>
             </div>

          </div>
        </div>
      </div>
    </div>
  );
}

export default experience;
