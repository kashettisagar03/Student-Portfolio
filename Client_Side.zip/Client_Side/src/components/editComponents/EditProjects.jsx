import React from "react";
import { Link } from "react-router-dom";
import "./Edit.css";

const EditProjects = () => {
  return (
    <div className="edit">
      <div className="main-container">
        <div className="same-component">
          <div className="same-form">
            <form>
              <h3 className="updated">Updated</h3>
              <label htmlFor="text">Id</label>
              <input type="text" name="product_id" id="product_id" required />

              <label htmlFor="text">title</label>
              <input type="text" name="title" id="title" required />

              <label htmlFor="text">Description</label>
              <textarea
                type="text"
                name="description"
                id="description"
                required
                cols="30"
                rows="3"
              />
              <div className="upload">
                <input type="file" name="file" id="file_up" />
                <div id="file_img">
                  <img
                    src="https://it.sheridancollege.ca/images/virtualization.jpg"
                    width="100%"
                    alt=""
                  />
                  <span>X</span>
                </div>
              </div>
             <div className="btns">
              <button>Update item</button>
              <Link to='/admin'><button className="cancel-btn">Cancel</button></Link>
             </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditProjects;
