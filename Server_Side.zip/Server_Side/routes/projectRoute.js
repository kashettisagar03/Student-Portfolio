const router = require('express').Router();

// const {getProject,addProject,getProjectId,updateProject,deleteProject} = require('../controllers/projectCtrl');

const projectSchema = require('../models/projectModel');

//.............project.........

//get project user

router.get('/project',async (req,res)=>{
    try {
        const project = await projectSchema.find(req.body);
        res.json(project);
    } catch (error) {
        res.status(500).json({msg:err})
    }
})

//add project user

router.post('/project' ,async (req,res)=>{
    const {title , product_id , description , images} = req.body;
    
    try {
        const project = new projectSchema({
             product_id 
            , 
            title
            ,
             description 
            , 
            images
        })
        await project.save();
        res.json({msg:"Product Added"})
    } 
    catch (error) {
        res.status(500).json({msg:error})
    }
})

//get specific user by id
router.get('/project/:id',async (req,res)=>{
    try {
        let project = await projectSchema.findById(req.params.id)
        res.json(project)
    } catch (error) {
        res.status(500).json({msg:error})
    }
})

// update specific user by id
router.put('/project/update/:id',async (req,res)=>{
    const {title , product_id , description , images} = req.body;
    try {
        const project = await projectSchema.findByIdAndUpdate(req.params.id,{
           title,
           product_id,
           description,
           images
        })
        await project.save();
        res.json({msg:"Item Updated"})
    } catch (error) {
        
    }
})

// delete specific user by id
router.delete('/project/:id',async (req,res)=>{
    let project = await projectSchema.findByIdAndDelete(req.params.id);
    try {
        
       await project ;
       res.status(500).json({msg:err})
    } catch (error) {
        res.status(500).json({msg:error})
    }
})


module.exports = router;
