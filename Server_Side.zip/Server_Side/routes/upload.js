
const router = require('express').Router();

const cloudinary = require('cloudinary');
const fs = require('fs');

// we will upload image to cloudinary

cloudinary.config({
    cloud_name: process.env.CLOUD_NAME ,
    api_key : process.env.CLOUD_API_KEY ,
    api_secret : process.env.CLOUD_API_SECRET

})

//post upload image

router.post('/upload',(req,res)=>{
    try{
     if(!req.files || Object.keys(req.files).length === 0){
        return res.status(400).send('no files uploaded')
     }
     const file = req.files.file;
     if(file.size>1024*1024){
        remoeveTmp(file.tempFilePath); 
        return res.status(400).json({msg : 'size is to big'})
     }
     if(file.mimetype !=='image/jpeg' && file.mimetype !== 'image/png'){
         remoeveTmp(file.tempFilePath);
        return res.status(400).json({msg:'incorrect file format'})
     }
     
     cloudinary.v2.uploader.upload(file.tempFilePath,{folder:"my-portfolio"},
     async(err,result)=>{
        if(err) throw err;

        remoeveTmp(file.tempFilePath);
        res.json({public_id : result.public_id,url:result.secure_url})
     })
     
     

    }
    catch(err){
        res.status(500).json({msg:err.messagae})
    }
})

// delete image

const remoeveTmp=(path)=>{
    fs.unlink(path,err=>{
        if(err) throw err;
    })
}

module.exports = router ;