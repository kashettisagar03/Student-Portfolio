const educationSchema = require('../models/educModel');

exports.getEducation = async (req,res)=>{
    const education = await educationSchema.find();

    try {
        res.json(education);
    } 
    catch (error) {
        res.status(500).json({msg:`server problem..`})
    }

    // //second way 
    // educationSchema.find()
    // .then(education=>res.json(education))
    // .catch(err=>res.status(500).json(`error:${err}`))
}


exports.addEducation = async (req,res)=>{
    const {education} = req.body;
    try {
        
        const newEducation = new educationSchema({
            education
        })
    
        await newEducation.save();
        res.json(newEducation);
    } 
    catch (error) {
        res.status(500).json({msg:'server problem..'})
    }

    // // second way promises
    // const newEducation = new educationSchema({
    //     education
    // })
    // newEducation.save()
    // .then(education=>res.json('The article was sended'))
    // .catch(err=>res.status(500).json(`error:${err}`))
}

exports.getEducationId = async (req,res)=>{

    try {
        const education =  await educationSchema.findById(req.params.id);
        res.json(education);
    } catch (error) {
        res.status(500).json({msg:'server problem..'})
    }

//    educationSchema.findById(req.params.id)
//   .then(education=>res.json(education))
//   .catch(err=>res.status(400).json({msg:err}))
}

exports.updateEducation = async (req,res)=>{
    const {education} = req.body;
    try {
        const newEducation = await educationSchema.findByIdAndUpdate(req.params.id,{
            education 
        });
        let results = await newEducation.save();
        await results;
        res.json({msg:'Item Updated'})
    } 
    catch (error) {
        res.status(500).json({msg:'server problem..'})
    }
}

exports.deleteEducation = async (req,res)=>{
    const education = await educationSchema.findByIdAndDelete(req.params.id)
    
    education;

    res.json({msg:"Item deleted"})
}