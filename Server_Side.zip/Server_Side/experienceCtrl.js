
const experienceSchema = require('./models/experienceModel');

exports.getExperience = async (req,res)=>{
    const experience = await experienceSchema.find();

    try {
        res.json(experience);
    } 
    catch (error) {
        res.status(500).json({msg:`server problem..`})
    }

    // //second way 
    // experienceSchema.find()
    // .then(experience=>res.json(experience))
    // .catch(err=>res.status(500).json(`error:${err}`))
}


exports.addExperience = async (req,res)=>{
    const {experience} = req.body;
    try {
        
        const newExperience = new experienceSchema({
            experience
        })
    
        await newExperience.save();
        res.json(newExperience);
    } 
    catch (error) {
        res.status(500).json({msg:'server problem..'})
    }

    // // second way promises
    // const newExperience = new experienceSchema({
    //     experience
    // })
    // newExperience.save()
    // .then(experience=>res.json('The article was sended'))
    // .catch(err=>res.status(500).json(`error:${err}`))
}

exports.getExperienceId = async (req,res)=>{

    try {
        const experience =  await experienceSchema.findById(req.params.id);
        res.json(experience);
    } catch (error) {
        res.status(500).json({msg:'server problem..'})
    }

//    experienceSchema.findById(req.params.id)
//   .then(experience=>res.json(experience))
//   .catch(err=>res.status(400).json({msg:err}))
}

exports.updateExperience = async (req,res)=>{
    const {experience} = req.body;
    try {
        const newExperience = await experienceSchema.findByIdAndUpdate(req.params.id,{
            experience 
        });
        let results = await newExperience.save();
        await results;
        res.json({msg:'Item Updated'})
    } 
    catch (error) {
        res.status(500).json({msg:'server problem..'})
    }
}

exports.deleteExperience = async (req,res)=>{
    const experience = await experienceSchema.findByIdAndDelete(req.params.id)
    
    experience;

    res.json({msg:"Item deleted"})
}